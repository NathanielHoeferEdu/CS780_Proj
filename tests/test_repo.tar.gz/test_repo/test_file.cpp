/**
This is a test file
*/

// This is a class specifically for comments
class Comments {

public:

    // This is a double!
    double number;

    /* Another comment by Billy */

};